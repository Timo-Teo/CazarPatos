package com.camuendotimoteo.cazarpatos

const val EXTRA_LOGIN = "EXTRA_LOGIN"
